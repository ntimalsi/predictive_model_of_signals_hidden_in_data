'''
Spirit Animal User ID: SalmonSloth
Date the file was last edited: November 13, 2018
Challenge Number: 5

SOURCES OF HELP:
a) Dr. Jones website https://john.cs.olemiss.edu/~jones/doku.php?id=csci343_linear_regression 
                     https://john.cs.olemiss.edu/~jones/doku.php?id=csci343_polynomial_regression  
b) Took help from Lecture 14,15 slides provided by Dr. Jones
c)https://www.mathsisfun.com/data/least-squares-regression.html
d) https://www.tutorialspoint.com/python/python_dictionary.htm
e) Googled some statistics terms
f)Took help from Paul.
g)DEMONSTRATED PROGRAM TO PAUL(T.A)
'''


#IMPORT REQUIRED MODULES
from __future__ import division
import numpy as np
import matplotlib.pyplot as mplot

#IMPORT DATA FROM FILE
fileOpen=open("SalmonSloth.csv", "r")
fileHandle= fileOpen.read()
dataList=fileHandle.split("\n")
dataList.pop() #delete the last extraneous space

#MAKE A DICTIONARY TO STORE TIME AND INTENSITY FOR THE SPECIFIC FREQUENCY
freqDict={}
for value in dataList:
    singleValue=value.split(",")
    if np.float32(singleValue[1]) not in freqDict:
        freqDict[np.float32(singleValue[1])]=[[np.float32(singleValue[0])], [np.float32(singleValue[2])]]
    else:
        freqDict[np.float32(singleValue[1])][0].append(np.float32(singleValue[0]))
        freqDict[np.float32(singleValue[1])][1].append(np.float32(singleValue[2]))

#DECLARE INITIAL LISTS TO STORE DATA LATER

freqList=[]
correlation=[]
#CREATE THE GRAPH LABELS
mplot.title("Challenge 5")
mplot.xlabel("Time(ms)")
mplot.ylabel("Signal Intensity")
colors=["orange","r","g","b","purple"]
colorPosition=0
corDict={}#TO STORE FREQUENCY FOR THE HIGHEST CORRELATION VALUES
###################################################################################
#PLOT ALL THE GIVEN DATA AS A SCATTERPLOT
for freq in freqDict:
    mplot.scatter(freqDict[freq][0], freqDict[freq][1],color=colors[colorPosition])
    #CALCULATE CORRELATION OF THE SPECIFIC FREQUENCIES
    correlate_calc=np.corrcoef( freqDict[freq][0], freqDict[freq][1])
    corDict[correlate_calc[0][1]]=freq
    freqList.append(freq)
    correlation.append(correlate_calc[0][1])
    colorPosition+=1
#####################################################################################

############################IDENTIFY 2 STRUCTURED FREQUENCIES######################################################
correlation=sorted(correlation)
maxCor1=correlation[0]
maxCor2=correlation[1]

maxfreq1=corDict[maxCor1]
maxfreq2=corDict[maxCor2]
####################################################################################################################

#################################################################################
#STORE THE CORRESPONDING TIME AND FREQUENCY FOR THE 2 STRUCTURED FREQUENCIES
max1Values=freqDict[maxfreq1]
max2Values=freqDict[maxfreq2]
#################################################################################

###################################################################################################
###################################################################################################
#########################LINEAR REGRESSSION#######################################################
#CALCULATE SLOPE AND Y INTERCEPT(LINEAR REGRESSION) FROM THE VALUES OF THE 2 STRUCTURED GROUP
###################################################################################################
slope1=np.corrcoef(max1Values[0], max1Values[1])[1][0]*np.std(max1Values[1])/np.std(max1Values[0])
y_intercept1= np.mean(max1Values[1])-slope1*np.mean(max1Values[0])

slope2=np.corrcoef(max2Values[0], max2Values[1])[1][0]*np.std(max2Values[1])/np.std(max2Values[0])
y_intercept2= np.mean(max2Values[1])-slope1*np.mean(max2Values[0])
###################################################################################################


####PREDICT THE Y VALUES FOR THE X VALUES#########################################################
y1pred=[]
y2pred=[]
for i in max1Values[0]:
    y1pred.append(slope1*i+y_intercept1)

for j in max2Values[0]:
    y2pred.append(slope2*j+y_intercept2)
##################################################################################################
###################################################################################################
###################################################################################################
##################################################################################################



### FOR POLYNOMIAL REGRESSION#########################
###################################################################################################
degree=int(raw_input("Enter your degree: "))
#calculates regression parameters to model our raw data
params=np.polyfit(max1Values[0], max1Values[1], degree)
#new range of x-values to test
x1new=np.float32(range(0, 100))

#generates the predicted y-values
ypred=np.polyval(params, x1new)

#make a line plot of our predicted data
params=np.polyfit(max2Values[0], max2Values[1], degree)
#new range of x-values to test
x2new=np.float32(range(0, 100))

#generates the predicted y-values
ypred1=np.polyval(params, x2new)
###################################################################################################
###################################################################################################

#*************************************************************************************************#
#*************************************************************************************************#
#*************************************************************************************************#
#####PLOT############################################
mplot.scatter(max1Values[0], max1Values[1], color="#CC99FF")
mplot.scatter(max2Values[0], max2Values[1], color="red")
mplot.plot(x1new, ypred, c="blue")
mplot.plot(x2new, ypred1, c="blue")
mplot.plot(max1Values[0], y1pred, color="red", linestyle="-")
mplot.plot(max2Values[0], y2pred, color="red", linestyle="-")
mplot.show()    
#*************************************************************************************************#
#*************************************************************************************************#
#*************************************************************************************************#
###################################################
